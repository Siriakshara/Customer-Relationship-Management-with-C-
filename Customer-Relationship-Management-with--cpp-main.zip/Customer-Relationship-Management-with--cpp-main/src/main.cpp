#include "utils.h"
#include "Clients_Management.h"

// Main file to execute the entire code  
int main(){

    ClientsManagement management;
    user_input(management);

    return 0;
}